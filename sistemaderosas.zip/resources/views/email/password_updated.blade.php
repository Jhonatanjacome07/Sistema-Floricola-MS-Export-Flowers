<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Confirmación de cambio de contraseña</title>
</head>
<body>
    <h2>Confirmación de cambio de contraseña</h2>
    
    <p>Hola {{ $user->name }},</p>
    
    <p>Te escribimos para confirmar que tu contraseña ha sido actualizada correctamente en MS EXPORT FLOWERS.</p>
    
    <p>Si no realizaste esta acción, por favor contacta con nuestro equipo de soporte lo antes posible.</p>
    
    <p>¡Gracias por confiar en nosotros!</p>
    
    <p>Saludos,<br>Equipo de MS EXPORT FLOWERS</p>
</body>
</html>
