<?php $__env->startSection('title', 'Inicio'); ?>

<?php $__env->startSection('content_header'); ?>
<h1 class="text-center"> <b>MSFLOWERS</b></h1>
<div class="text-center">
    <img src="/images/logo.jpg" alt="Logo" width="150px" class="rounded-circle">
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>


<p class="text-center">Bienvenido <b><?php echo e(Auth::user()->name); ?> <?php echo e(Auth::user()->lastname); ?></b>, tus roles son:
    <?php $__currentLoopData = Auth::user()->roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php echo e($role->name); ?>

        <?php if(!$loop->last): ?>
            
        <?php endif; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</p>

<?php if(\Spatie\Permission\PermissionServiceProvider::bladeMethodWrapper('hasRole', 'Administrador')): ?>
<div class="row">
    <div class="col-md-3 col-sm-6 col-12">
        <div class="info-box  ">
            <span class="info-box-icon bg-danger elevation-12"><i class="fas fa-user-plus"></i></span>
            <div class="info-box-content">
                <a href="<?php echo e(route('Administrador.index')); ?>" class="text-dark">
                    <span class="info-box-text"><b>Registrar Usuarios</b></span>
                    <span class="info-box-number">
                    </span>
                </a>
            </div>
        </div>
    </div>
    <div class="col-md-3 col-sm-6 col-12">
        <div class="info-box  ">
            <span class="info-box-icon bg-danger elevation-12"><i class="fas fa-user-plus"></i></span>
            <div class="info-box-content">
                <a href="<?php echo e(route('roles.index')); ?>" class="text-dark">
                    <span class="info-box-text"><b>Registrar Roles </b></span>
                    <span class="info-box-number">
                    </span>
                </a>
            </div>
        </div>
    </div>
    <div class="col-md-3 col-sm-6 col-12">
        <div class="info-box  ">
            <span class="info-box-icon bg-danger elevation-12"><i class="fas fa-user-plus"></i></span>
            <div class="info-box-content">
                <a href="<?php echo e(route('permisos.index')); ?>" class="text-dark">
                    <span class="info-box-text"><b>Registrar Permisos</b></span>
                    <span class="info-box-number">
                    </span>
                </a>
            </div>
        </div>
    </div>
    <div class="col-md-3 col-sm-6 col-12">
        <div class="info-box  ">
            <span class="info-box-icon bg-danger elevation-12"><i class="fas fa-user-plus"></i></span>
            <div class="info-box-content">
                <a href="<?php echo e(route('asignar.index')); ?>" class="text-dark">
                    <span class="info-box-text"><b>Asignar Roles</b></span>
                    <span class="info-box-number">
                    </span>
                </a>
            </div>
        </div>
    </div>
    <div class="col-md-3 col-sm-6 col-12">
        <div class="info-box  ">
            <span class="info-box-icon bg-danger elevation-12"><i class="fas fa-seedling"></i></span>
            <div class="info-box-content">
                <a href="<?php echo e(route('flowers.index')); ?>" class="text-dark">
                    <span class="info-box-text"><b>Registrar Variedades</b></span>
                    <span class="info-box-number">
                    </span>
                </a>
            </div>
        </div>
    </div>
    <div class="col-md-3 col-sm-6 col-12">
        <div class="info-box  ">
            <span class="info-box-icon bg-danger elevation-12"><i class="fa fa-spa"></i></span>
            <div class="info-box-content">
                <a href="<?php echo e(route('plagas.index')); ?>" class="text-dark">
                    <span class="info-box-text"><b>Registrar Plagas</b></span>
                    <span class="info-box-number">
                    </span>
                </a>
            </div>
        </div>
    </div>
</div>
<div class="container">
    <h1 class="text-center"> <b>Rosas</b></h1>

    <div class="row">
        <div class="col-md-12">
            <div id="gallery" class="row">
                <div class="col-sm-3">
                    <a href="<?php echo e(asset('assets/img/portfolio/highmagic.jpg')); ?>" data-toggle="lightbox"
                        data-gallery="gallery" class="d-block mb-4">
                        <img src="<?php echo e(asset('assets/img/portfolio/highmagic.jpg')); ?>" class="img-fluid img-thumbnail">
                    </a>
                </div>
                <div class="col-sm-3">
                    <a href="<?php echo e(asset('assets/img/portfolio/FREEDOM.jpg')); ?>" data-toggle="lightbox"
                        data-gallery="gallery" class="d-block mb-4">
                        <img src="<?php echo e(asset('assets/img/portfolio/FREEDOM.jpg')); ?>" class="img-fluid img-thumbnail">
                    </a>
                </div>
            </div>
        </div>
    </div>
</div>
<?php endif; ?>

<?php if(\Spatie\Permission\PermissionServiceProvider::bladeMethodWrapper('hasRole', 'Recepcionista')): ?>
<div class="row">
    <div class="col-md-3 col-sm-6 col-12">
        <div class="info-box  ">
            <span class="info-box-icon bg-danger elevation-12"><i class="fas fa-user-plus"></i></span>
            <div class="info-box-content">
                <a href="<?php echo e(route('recepcion.create')); ?>" class="text-dark">
                    <span class="info-box-text"><b>Registrar producción</b></span>
                    <span class="info-box-number">
                    </span>
                </a>
            </div>
        </div>
    </div>
    <div class="col-md-3 col-sm-6 col-12">
        <div class="info-box  ">
            <span class="info-box-icon bg-danger elevation-12"><i class="fas fa-user-plus"></i></span>
            <div class="info-box-content">
                <a href="<?php echo e(route('recepcion.index')); ?>" class="text-dark">
                    <span class="info-box-text"><b>Lista de producción</b></span>
                    <span class="info-box-number">
                    </span>
                </a>
            </div>
        </div>
    </div>
    <div class="col-md-3 col-sm-6 col-12">
        <div class="info-box  ">
            <span class="info-box-icon bg-danger elevation-12"><i class="fas fa-seedling"></i></span>
            <div class="info-box-content">
                <a href="<?php echo e(route('recepcionreporte')); ?>" class="text-dark">
                    <span class="info-box-text"><b>Reportes</b></span>
                    <span class="info-box-number">
                    </span>
                </a>
            </div>
        </div>
    </div>
</div>
<?php endif; ?>

<?php if(\Spatie\Permission\PermissionServiceProvider::bladeMethodWrapper('hasRole', 'Flor nacional')): ?>
<div class="row">
    <div class="col-md-3 col-sm-6 col-12">
        <div class="info-box  ">
            <span class="info-box-icon bg-danger elevation-12"><i class="fas fa-user-plus"></i></span>
            <div class="info-box-content">
                <a href="<?php echo e(route('flornacional.create')); ?>" class="text-dark">
                    <span class="info-box-text"><b>Registrar flor nacional</b></span>
                    <span class="info-box-number">
                    </span>
                </a>
            </div>
        </div>
    </div>
    <div class="col-md-3 col-sm-6 col-12">
        <div class="info-box  ">
            <span class="info-box-icon bg-danger elevation-12"><i class="fas fa-user-plus"></i></span>
            <div class="info-box-content">
                <a href="<?php echo e(route('flornacional.index')); ?>" class="text-dark">
                    <span class="info-box-text"><b>Lista de flor nacional</b></span>
                    <span class="info-box-number">
                    </span>
                </a>
            </div>
        </div>
    </div>
    <div class="col-md-3 col-sm-6 col-12">
        <div class="info-box  ">
            <span class="info-box-icon bg-danger elevation-12"><i class="fas fa-seedling"></i></span>
            <div class="info-box-content">
                <a href="<?php echo e(route('flornacionalreporte')); ?>" class="text-dark">
                    <span class="info-box-text"><b>Reportes</b></span>
                    <span class="info-box-number">
                    </span>
                </a>
            </div>
        </div>
    </div>
</div>
<?php endif; ?>

<?php if(\Spatie\Permission\PermissionServiceProvider::bladeMethodWrapper('hasRole', 'Digitador')): ?>
<div class="row">
    <div class="col-md-3 col-sm-6 col-12">
        <div class="info-box  ">
            <span class="info-box-icon bg-danger elevation-12"><i class="fas fa-user-plus"></i></span>
            <div class="info-box-content">
                <a href="<?php echo e(route('digitador.create')); ?>" class="text-dark">
                    <span class="info-box-text"><b>Registrar bonche</b></span>
                    <span class="info-box-number">
                    </span>
                </a>
            </div>
        </div>
    </div>
    <div class="col-md-3 col-sm-6 col-12">
        <div class="info-box  ">
            <span class="info-box-icon bg-danger elevation-12"><i class="fas fa-user-plus"></i></span>
            <div class="info-box-content">
                <a href="<?php echo e(route('digitador.index')); ?>" class="text-dark">
                    <span class="info-box-text"><b>Lista de bonches</b></span>
                    <span class="info-box-number">
                    </span>
                </a>
            </div>
        </div>
    </div>
    <div class="col-md-3 col-sm-6 col-12">
        <div class="info-box  ">
            <span class="info-box-icon bg-danger elevation-12"><i class="fas fa-seedling"></i></span>
            <div class="info-box-content">
                <a href="<?php echo e(route('boncheoreporte')); ?>" class="text-dark">
                    <span class="info-box-text"><b>Reportes</b></span>
                    <span class="info-box-number">
                    </span>
                </a>
            </div>
        </div>
    </div>
</div>
<?php endif; ?>


<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
<link rel="stylesheet" href="/css/admin_custom.css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<script>
    console.log('Hi!'); 
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\sistemaderosas\resources\views/dashboard.blade.php ENDPATH**/ ?>