<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Usuario Eliminado</title>
</head>
<body>
    <h2>¡Hola <?php echo e($user->name); ?>!</h2>
    
    <p>Tu cuenta en MS EXPORT FLOWERS ha sido eliminada del sistema.</p>
    
    <p>Gracias por ser parte de nuestra plataforma.</p>
    
    <p>Saludos,<br>Equipo de MS EXPORT FLOWERS</p>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\sistemaderosas\resources\views/email/usuario_eliminado.blade.php ENDPATH**/ ?>