

<?php $__env->startSection('title', 'Plagas'); ?>

<?php $__env->startSection('content_header'); ?>
<h1 class="text-center"> <b>Plagas</b></h1>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="card-header container">
    <div class="row">
        <div class="col-lg-6 col-md-6 col-sm-12">
            <a href="<?php echo e(route('plagas.create')); ?>" class="btn btn-primary"><b>Agregar nueva plaga</b></a>
        </div>

    </div>

</div>

<div class="card">
    <div class="card-body">
        <div class="table-responsive">
            <table id="rosas" class="table table-striped table-bordered nowrap table-info">
                <thead>
                    <tr>
                        <th>Nr</th>
                        <th>Nombre</th>
                        <th>Estado</th>
                        <th>Acciones</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $contador=0;?>
                    <?php $__currentLoopData = $plagas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $plaga): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo $contador= $contador + 1;?></td>
                        <td><?php echo e($plaga->name); ?></td>
                        <td id="resp<?php echo e($plaga->id); ?>">
                            <?php if($plaga->status == 1): ?>
                            <span class="text-success">Activo</span>
                            <?php else: ?>
                            <span class="text-danger">Inactivo</span>
                            <?php endif; ?>
                        </td>
                        <td>
                            <button class="btnEditar btn btn-xs btn-default text-primary mx-1 shadow" data-id="<?php echo e($plaga->id); ?>" data-name="<?php echo e($plaga->name); ?>" title="Editar">
                                <i class="fa fa-lg fa-fw fa-pen"></i>
                            </button>
                            <button class="btnActivar btn btn-xs btn-default text-primary mx-1 shadow" data-id="<?php echo e($plaga->id); ?>" data-status="<?php echo e($plaga->status); ?>" title="Activar/Desactivar">
                                <i class="fa fa-lg fa-fw <?php echo e($plaga->status == 1 ? 'fa-toggle-on text-success' : 'fa-toggle-off text-danger'); ?>"></i>
                            </button>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
</div>


    
    <?php if (isset($component)) { $__componentOriginale2dfb698641700bc6575e0f9f2d3d632 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginale2dfb698641700bc6575e0f9f2d3d632 = $attributes; } ?>
<?php $component = JeroenNoten\LaravelAdminLte\View\Components\Tool\Modal::resolve(['id' => 'modalEditPlaga','title' => 'Editar Plaga','theme' => 'success','icon' => 'fas fa-edit','size' => 'lg','disableAnimations' => true] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('adminlte-modal'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(JeroenNoten\LaravelAdminLte\View\Components\Tool\Modal::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
        <form id="formEditPlaga" method="POST">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>
            <?php if (isset($component)) { $__componentOriginale5d826ae10df3aa87f8449f474c11664 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginale5d826ae10df3aa87f8449f474c11664 = $attributes; } ?>
<?php $component = JeroenNoten\LaravelAdminLte\View\Components\Form\Input::resolve(['name' => 'name','label' => 'Nombre','labelClass' => 'text-success'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('adminlte-input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(JeroenNoten\LaravelAdminLte\View\Components\Form\Input::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['placeholder' => 'Nombre de la plaga']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginale5d826ae10df3aa87f8449f474c11664)): ?>
<?php $attributes = $__attributesOriginale5d826ae10df3aa87f8449f474c11664; ?>
<?php unset($__attributesOriginale5d826ae10df3aa87f8449f474c11664); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale5d826ae10df3aa87f8449f474c11664)): ?>
<?php $component = $__componentOriginale5d826ae10df3aa87f8449f474c11664; ?>
<?php unset($__componentOriginale5d826ae10df3aa87f8449f474c11664); ?>
<?php endif; ?>
            <?php if (isset($component)) { $__componentOriginal84b78d66d5203b43b9d8c22236838526 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal84b78d66d5203b43b9d8c22236838526 = $attributes; } ?>
<?php $component = JeroenNoten\LaravelAdminLte\View\Components\Form\Button::resolve(['type' => 'submit','label' => 'Actualizar','theme' => 'success','icon' => 'fas fa-save'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('adminlte-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(JeroenNoten\LaravelAdminLte\View\Components\Form\Button::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal84b78d66d5203b43b9d8c22236838526)): ?>
<?php $attributes = $__attributesOriginal84b78d66d5203b43b9d8c22236838526; ?>
<?php unset($__attributesOriginal84b78d66d5203b43b9d8c22236838526); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal84b78d66d5203b43b9d8c22236838526)): ?>
<?php $component = $__componentOriginal84b78d66d5203b43b9d8c22236838526; ?>
<?php unset($__componentOriginal84b78d66d5203b43b9d8c22236838526); ?>
<?php endif; ?>
        </form>
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginale2dfb698641700bc6575e0f9f2d3d632)): ?>
<?php $attributes = $__attributesOriginale2dfb698641700bc6575e0f9f2d3d632; ?>
<?php unset($__attributesOriginale2dfb698641700bc6575e0f9f2d3d632); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale2dfb698641700bc6575e0f9f2d3d632)): ?>
<?php $component = $__componentOriginale2dfb698641700bc6575e0f9f2d3d632; ?>
<?php unset($__componentOriginale2dfb698641700bc6575e0f9f2d3d632); ?>
<?php endif; ?>


<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>


<script>
    $(document).ready(function() {
        $('#rosas').DataTable({
            "language": {
                "search": "Buscar",
                "lengthMenu": "Mostrar _MENU_ resgistros por página",
                "info": "Mostrando página _PAGE_ de _PAGES_",
                "paginate": {
                    "previous": "Anterior",
                    "next": "Siguiente",
                    "first": "Primero",
                    "last": "Último"
                }
            },
            "lengthMenu": [5, 10, 15],
            "responsive": true,
            "autoWidth": false
        });
    });
</script>
<script>
    $(document).ready(function() {
      $('.btnActivar').on('click', function() {
          var plagaId = $(this).data('id');
          var nuevoEstado = $(this).data('status') == 1 ? 0 : 1;

          $.ajax({
              url: '<?php echo e(route("plagas.toggle", ":plagaId")); ?>'.replace(':plagaId', plagaId),
              method: 'PUT',
              data: {
                  _token: '<?php echo e(csrf_token()); ?>',
                  _method: 'PUT'
              },
              success: function(response) {
                  // Actualizar el estado en la tabla
                   // Actualizar el estado en la tabla
                   $('#resp' + plagaId).html(nuevoEstado == 1 ? '<span class="text-success">Activo</span>' : '<span class="text-danger">Inactivo</span>');
                   $('.btnActivar[data-id="' + plagaId + '"]').data('status', nuevoEstado);
                  // Actualizar el icono del botón de activar/desactivar
                  $('.btnActivar[data-id="' + plagaId + '"]').html('<i class="fa fa-lg fa-fw ' + (nuevoEstado == 1 ? 'fa-toggle-on text-success' : 'fa-toggle-off text-danger') + '"></i>');
                  // Actualizar el atributo data-status del botón
                  var iconClass = nuevoEstado == 1 ? 'fa-toggle-on text-success' : 'fa-toggle-off text-danger';
                  $('.btnActivar[data-id="' + plagaId + '"]').data('status', nuevoEstado);
              },
              error: function(xhr) {
                  console.error(xhr);
              }
          });
      });
  });
</script>


<script>
    document.addEventListener('DOMContentLoaded', function () {
    var botonesEditar = document.querySelectorAll('.btnEditar');
    botonesEditar.forEach(function (boton) {
        boton.addEventListener('click', function (event) {
            event.preventDefault();
            var idPlaga = boton.getAttribute('data-id');
            var nombrePlaga = boton.getAttribute('data-name');
            // Colocar el ID de la plaga en el formulario de edición
            document.querySelector('#formEditPlaga').setAttribute('action', "<?php echo e(url('Plagas')); ?>/" + idPlaga);
            // Rellenar el campo de nombre con el nombre de la plaga
            document.querySelector('#modalEditPlaga input[name="name"]').value = nombrePlaga;

            // Abrir el modal de edición
            $('#modalEditPlaga').modal('show');
        });
    });
    // Manejar la respuesta de actualización con SweetAlert
    $('#formEditPlaga').submit(function (event) {
        event.preventDefault();
        var formData = $(this).serialize();
        var actionUrl = $(this).attr('action');
        $.ajax({
            url: actionUrl,
            method: 'PUT',
            data: formData,
            success: function (response) {
                // Mostrar SweetAlert cuando los datos se actualicen correctamente
                Swal.fire({
                    title: 'Éxito',
                    text: response.message,
                    icon: 'success',
                    timer: 2000 // 2 segundos
                }).then(function () {
                    // Recargar la página después de cerrar el SweetAlert
                    location.reload();
                });
            },
            error: function (xhr) {
                // Manejar errores si es necesario
                console.error(xhr);
            }
        });
    });
});
</script>





<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\sistemaderosas\resources\views/plagas/index.blade.php ENDPATH**/ ?>