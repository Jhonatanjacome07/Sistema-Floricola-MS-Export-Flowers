

<?php $__env->startSection('title', 'Inicio'); ?>

<?php $__env->startSection('content_header'); ?>
    <h1 class="text-center"> <b>MSFLOWERS</b></h1>
    <div class="text-center">
        <img src="/images/logo.jpg" alt="Logo" width="150px" class="rounded-circle">
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<p class="text-center">Bienvenido <b><?php echo e(Auth::user()->name); ?> <?php echo e(Auth::user()->lastname); ?></b>, 
    <?php $__currentLoopData = Auth::user()->roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php echo e($role->name); ?>

        <?php if(!$loop->last): ?>
            
        <?php endif; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</p>
    <?php if(\Spatie\Permission\PermissionServiceProvider::bladeMethodWrapper('hasRole', 'Administrador')): ?>
        <div class="row">
            <div class="col-md-3 col-sm-6 col-12">
                <div class="info-box  ">
                    <span class="info-box-icon bg-danger elevation-12"><i class="fas fa-user-plus"></i></span>
                    <div class="info-box-content">
                        <a href="<?php echo e(route('Administrador.index')); ?>" class="text-dark">
                            <span class="info-box-text"><b>Registrar Usuarios</b></span>
                            <span class="info-box-number">
                            </span>
                        </a>
                    </div>
                </div>
            </div>
            <div class="col-md-3 col-sm-6 col-12">
                <div class="info-box  ">
                    <span class="info-box-icon bg-danger elevation-12"><i class="fas fa-user-plus"></i></span>
                    <div class="info-box-content">
                        <a href="<?php echo e(route('roles.index')); ?>" class="text-dark">
                            <span class="info-box-text"><b>Registrar Roles </b></span>
                            <span class="info-box-number">
                            </span>
                        </a>
                    </div>
                </div>
            </div>
            <div class="col-md-3 col-sm-6 col-12">
                <div class="info-box  ">
                    <span class="info-box-icon bg-danger elevation-12"><i class="fas fa-user-plus"></i></span>
                    <div class="info-box-content">
                        <a href="<?php echo e(route('permisos.index')); ?>" class="text-dark">
                            <span class="info-box-text"><b>Registrar Permisos</b></span>
                            <span class="info-box-number">
                            </span>
                        </a>
                    </div>
                </div>
            </div>
            <div class="col-md-3 col-sm-6 col-12">
                <div class="info-box  ">
                    <span class="info-box-icon bg-danger elevation-12"><i class="fas fa-user-plus"></i></span>
                    <div class="info-box-content">
                        <a href="<?php echo e(route('asignar.index')); ?>" class="text-dark">
                            <span class="info-box-text"><b>Asignar Roles</b></span>
                            <span class="info-box-number">
                            </span>
                        </a>
                    </div>
                </div>
            </div>
            <div class="col-md-3 col-sm-6 col-12">
                <div class="info-box  ">
                    <span class="info-box-icon bg-danger elevation-12"><i class="fas fa-seedling"></i></span>
                    <div class="info-box-content">
                        <a href="<?php echo e(route('flowers.index')); ?>" class="text-dark">
                            <span class="info-box-text"><b>Registrar Variedades</b></span>
                            <span class="info-box-number">
                            </span>
                        </a>
                    </div>
                </div>
            </div>
            <div class="col-md-3 col-sm-6 col-12">
                <div class="info-box  ">
                    <span class="info-box-icon bg-danger elevation-12"><i class="fa fa-spa"></i></span>
                    <div class="info-box-content">
                        <a href="<?php echo e(route('plagas.index')); ?>" class="text-dark">
                            <span class="info-box-text"><b>Registrar Plagas</b></span>
                            <span class="info-box-number">
                            </span>
                        </a>
                    </div>
                </div>
            </div>
            <div class="col-md-3 col-sm-6 col-12">
                <div class="info-box">
                    <span class="info-box-icon bg-danger elevation-12"><i class="fas fa-file-pdf"></i></span>
                    <div class="info-box-content">
                        <a href="<?php echo e(asset('assets/manual/Manual de usuario.pdf')); ?>" download class="text-dark">
                            <span class="info-box-text"><b>Manual de Usuarios</b></span>
                            <span class="info-box-number"></span>
                        </a>
                    </div>
                </div>
            </div>
           

        </div>
    <?php endif; ?>
    
    <?php if(\Spatie\Permission\PermissionServiceProvider::bladeMethodWrapper('hasRole', 'Recepcionista')): ?>
        <div class="row">
            <div class="col-md-3 col-sm-6 col-12">
                <div class="info-box  ">
                    <span class="info-box-icon bg-danger elevation-12"><i class="fas fa-user-plus"></i></span>
                    <div class="info-box-content">
                        <a href="<?php echo e(route('recepcion.create')); ?>" class="text-dark">
                            <span class="info-box-text"><b>Registrar producción</b></span>
                            <span class="info-box-number">
                            </span>
                        </a>
                    </div>
                </div>
            </div>
            <div class="col-md-3 col-sm-6 col-12">
                <div class="info-box  ">
                    <span class="info-box-icon bg-danger elevation-12"><i class="fas fa-user-plus"></i></span>
                    <div class="info-box-content">
                        <a href="<?php echo e(route('recepcion.index')); ?>" class="text-dark">
                            <span class="info-box-text"><b>Lista de producción</b></span>
                            <span class="info-box-number">
                            </span>
                        </a>
                    </div>
                </div>
            </div>
            <div class="col-md-3 col-sm-6 col-12">
                <div class="info-box  ">
                    <span class="info-box-icon bg-danger elevation-12"><i class="fas fa-seedling"></i></span>
                    <div class="info-box-content">
                        <a href="<?php echo e(route('recepcionreporte')); ?>" class="text-dark">
                            <span class="info-box-text"><b>Reportes</b></span>
                            <span class="info-box-number">
                            </span>
                        </a>
                    </div>
                </div>
            </div>
        </div>
    
        <h1 class="text-center"> <b>Rosas</b></h1>
        <div class="row">
            <div class="col-sm-2">
                <a href="<?php echo e(asset('assets/img/portfolio/highmagic.jpg')); ?>" data-toggle="lightbox" 
                     data-gallery="gallery "  class="d-block mb-4">
                    <img src="<?php echo e(asset('assets/img/portfolio/highmagic.jpg')); ?>" class="img-fluid custom-thumbnail">
                </a>
                <div class="text-center">High & Magic</div>
            </div>
            <div class="col-sm-2">
                <a href="<?php echo e(asset('assets/img/portfolio/FREEDOM.jpg')); ?>" data-toggle="lightbox"
                    data-gallery="gallery" class="d-block mb-4">
                    <img src="<?php echo e(asset('assets/img/portfolio/FREEDOM.jpg')); ?>" class="img-fluid custom-thumbnail" >
                </a>
                <div class="text-center">Freedom</div>
            </div>
            <div class="col-sm-2">
                <a href="<?php echo e(asset('assets/img/portfolio/frutteto.jpg')); ?>" data-toggle="lightbox" data-gallery="gallery"
                    class="d-block mb-4">
                    <img src="<?php echo e(asset('assets/img/portfolio/frutteto.jpg')); ?>" class="img-fluid custom-thumbnail">
                </a>
                <div class="text-center">Frutteto</div>
            </div>
            <div class="col-sm-2">
                <a href="<?php echo e(asset('assets/img/portfolio/mandala.jpg')); ?>" data-toggle="lightbox" data-gallery="gallery"
                    class="d-block mb-4">
                    <img src="<?php echo e(asset('assets/img/portfolio/mandala.jpg')); ?>" class="img-fluid custom-thumbnail">
                </a>
                <div class="text-center">Mandala</div>
            </div>
            <div class="col-sm-2">
                <a href="<?php echo e(asset('assets/img/portfolio/ocean.jpg')); ?>" data-toggle="lightbox" data-gallery="gallery"
                    class="d-block mb-4">
                    <img src="<?php echo e(asset('assets/img/portfolio/ocean.jpg')); ?>" class="img-fluid custom-thumbnail">
                </a>
                <div class="text-center">Ocean Song</div>
            </div>
            <div class="col-sm-2">
                <a href="<?php echo e(asset('assets/img/portfolio/brighton.jpg')); ?>" data-toggle="lightbox" data-gallery="gallery"
                    class="d-block mb-4">
                    <img src="<?php echo e(asset('assets/img/portfolio/brighton.jpg')); ?>" class="img-fluid custom-thumbnail">
                </a>
                <div class="text-center">Brighton</div>
            </div>
        </div>
    <?php endif; ?>
    
    <?php if(\Spatie\Permission\PermissionServiceProvider::bladeMethodWrapper('hasRole', 'Flor nacional')): ?>
        <div class="row">
            <div class="col-md-3 col-sm-6 col-12">
                <div class="info-box  ">
                    <span class="info-box-icon bg-danger elevation-12"><i class="fas fa-user-plus"></i></span>
                    <div class="info-box-content">
                        <a href="<?php echo e(route('flornacional.create')); ?>" class="text-dark">
                            <span class="info-box-text"><b>Registrar flor nacional</b></span>
                            <span class="info-box-number">
                            </span>
                        </a>
                    </div>
                </div>
            </div>
            <div class="col-md-3 col-sm-6 col-12">
                <div class="info-box  ">
                    <span class="info-box-icon bg-danger elevation-12"><i class="fas fa-user-plus"></i></span>
                    <div class="info-box-content">
                        <a href="<?php echo e(route('flornacional.index')); ?>" class="text-dark">
                            <span class="info-box-text"><b>Lista de flor nacional</b></span>
                            <span class="info-box-number">
                            </span>
                        </a>
                    </div>
                </div>
            </div>
            <div class="col-md-3 col-sm-6 col-12">
                <div class="info-box  ">
                    <span class="info-box-icon bg-danger elevation-12"><i class="fas fa-seedling"></i></span>
                    <div class="info-box-content">
                        <a href="<?php echo e(route('flornacionalreporte')); ?>" class="text-dark">
                            <span class="info-box-text"><b>Reportes</b></span>
                            <span class="info-box-number">
                            </span>
                        </a>
                    </div>
                </div>
            </div>
        </div>
        
        <div class="card card-success">
            <div class="card-header">
                <h4 class="card-title">Plagas</h4>
            </div>
                <div class="card-body">
                    
                        <div class="row">
                            <div class="col-sm-2">
                                <a href="<?php echo e(asset('assets/img/plagas/arania.jpg')); ?>" data-toggle="lightbox" 
                                     data-gallery="gallery "  class="d-block mb-4">
                                    <img src="<?php echo e(asset('assets/img/plagas/arania.jpg')); ?>" class="img-fluid custom-thumbnail">
                                </a>
                                <div class="text-center">Araña</div>
                            </div>
                            <div class="col-sm-2">
                                <a href="<?php echo e(asset('assets/img/plagas/botritis.jpg')); ?>" data-toggle="lightbox"
                                    data-gallery="gallery" class="d-block mb-4">
                                    <img src="<?php echo e(asset('assets/img/plagas/botritis.jpg')); ?>" class="img-fluid custom-thumbnail" >
                                </a>
                                <div class="text-center">Botritis</div>
                            </div>
                            <div class="col-sm-2">
                                <a href="<?php echo e(asset('assets/img/plagas/clorosis.jpg')); ?>" data-toggle="lightbox" data-gallery="gallery"
                                    class="d-block mb-4">
                                    <img src="<?php echo e(asset('assets/img/plagas/clorosis.jpg')); ?>" class="img-fluid custom-thumbnail">
                                </a>
                                <div class="text-center">Clorosis</div>
                            </div>
                            <div class="col-sm-2">
                                <a href="<?php echo e(asset('assets/img/plagas/corto.jpg')); ?>" data-toggle="lightbox" data-gallery="gallery"
                                    class="d-block mb-4">
                                    <img src="<?php echo e(asset('assets/img/plagas/corto.jpg')); ?>" class="img-fluid custom-thumbnail">
                                </a>
                                <div class="text-center">Tallo Corto</div>
                            </div>
                            <div class="col-sm-2">
                                <a href="<?php echo e(asset('assets/img/plagas/cuellosdeganzos.jpg')); ?>" data-toggle="lightbox" data-gallery="gallery"
                                    class="d-block mb-4">
                                    <img src="<?php echo e(asset('assets/img/plagas/cuellosdeganzos.jpg')); ?>" class="img-fluid custom-thumbnail">
                                </a>
                                <div class="text-center">Cuello de Ganzo</div>
                            </div>
                            <div class="col-sm-2">
                                <a href="<?php echo e(asset('assets/img/plagas/trips.jpg')); ?>" data-toggle="lightbox" data-gallery="gallery"
                                    class="d-block mb-4">
                                    <img src="<?php echo e(asset('assets/img/plagas/trips.jpg')); ?>" class="img-fluid custom-thumbnail">
                                </a>
                                <div class="text-center">Trips</div>
                            </div>
                </div>
        </div>
    <?php endif; ?>
    
    <?php if(\Spatie\Permission\PermissionServiceProvider::bladeMethodWrapper('hasRole', 'Digitador')): ?>
        <div class="row">
            <div class="col-md-3 col-sm-6 col-12">
                <div class="info-box  ">
                    <span class="info-box-icon bg-danger elevation-12"><i class="fas fa-user-plus"></i></span>
                    <div class="info-box-content">
                        <a href="<?php echo e(route('digitador.create')); ?>" class="text-dark">
                            <span class="info-box-text"><b>Registrar bonche</b></span>
                            <span class="info-box-number">
                            </span>
                        </a>
                    </div>
                </div>
            </div>
            <div class="col-md-3 col-sm-6 col-12">
                <div class="info-box  ">
                    <span class="info-box-icon bg-danger elevation-12"><i class="fas fa-user-plus"></i></span>
                    <div class="info-box-content">
                        <a href="<?php echo e(route('digitador.index')); ?>" class="text-dark">
                            <span class="info-box-text"><b>Lista de bonches</b></span>
                            <span class="info-box-number">
                            </span>
                        </a>
                    </div>
                </div>
            </div>
            <div class="col-md-3 col-sm-6 col-12">
                <div class="info-box  ">
                    <span class="info-box-icon bg-danger elevation-12"><i class="fas fa-seedling"></i></span>
                    <div class="info-box-content">
                        <a href="<?php echo e(route('boncheoreporte')); ?>" class="text-dark">
                            <span class="info-box-text"><b>Reportes</b></span>
                            <span class="info-box-number">
                            </span>
                        </a>
                    </div>
                </div>
            </div>

        </div>
    <?php endif; ?>


<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="/css/admin_custom.css">
    <style>
        .custom-thumbnail {
            border: 7px solid #27cdba; /* Agrega el símbolo "#" antes del código hexadecimal */
        }
    </style>
<?php $__env->stopSection(); ?>



<?php $__env->startSection('js'); ?>
    <script>
        console.log('Hi!');
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\sistemaderosas\resources\views/admin/index.blade.php ENDPATH**/ ?>